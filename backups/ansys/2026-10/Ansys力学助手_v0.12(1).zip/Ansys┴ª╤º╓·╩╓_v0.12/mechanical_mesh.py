# Fixed IronPython mesh operations; all user choices arrive as validated JSON.
def mesh_quantity(value, unit=None):
    if unit and unicode(getattr(value,"Unit","")) not in ("","1","None"):
        return quantity_value(value,unit)
    return float(value.Value) if hasattr(value,"Value") else float(value)


def apply_face_mesh_controls(model, request):
    mesh=model.Mesh
    rows=request.get("mesh_controls",[])
    faces=geometry_entities(model,"face")
    selected=set(i for row in rows for i in row["face_ids"])
    if any(i not in faces for i in selected):raise Exception(u"局部网格面 ID 不属于当前活动几何")
    old=[];retained=[]
    for obj in list(mesh.Children):
        if unicode(obj.Name).startswith("AgentFaceSizing_") or unicode(obj.Name).startswith("AgentMappedFace_"):
            if kind(obj) not in ("Sizing","FaceMeshing"):raise Exception(u"程序网格名称与其他对象冲突")
            obj.Delete();continue
        if getattr(obj,"Suppressed",False):continue
        retained.append(brief(obj))
        if kind(obj) in ("Sizing","FaceMeshing"):
            try:ids=set(int(i) for i in obj.Location.Ids)
            except Exception:ids=set()
            body_faces=set()
            for body in walk(model.Geometry):
                if kind(body)=="Body" and not body.Suppressed and int(body.GetGeoBody().Id) in ids:
                    body_faces.update(int(f.Id) for f in body.GetGeoBody().Faces)
            if (ids|body_faces).intersection(selected):
                raise Exception(u"所选面与现有网格控制“"+unicode(obj.Name)+u"”冲突，请先在 Mechanical 中人工处理")
    mesh.ElementSize=Quantity(unicode(request["mesh_element_size_mm"])+" [mm]")
    applied=[]
    for index,row in enumerate(rows):
        selection=ExtAPI.SelectionManager.CreateSelectionInfo(SelectionTypeEnum.GeometryEntities)
        selection.Ids=row["face_ids"]
        sizing=mesh.AddSizing();sizing.Name="AgentFaceSizing_"+str(index+1);sizing.Location=selection
        sizing.ElementSize=Quantity(unicode(row["size_mm"])+" [mm]")
        sizing.Behavior=SizingBehavior.Hard if row["strategy"] in ("uniform","fine","coarse") else SizingBehavior.Soft
        if row["strategy"] in ("transition","curvature"):
            sizing.GrowthRate=float(row.get("growth_rate",1.2))
        if row["strategy"]=="curvature":
            sizing.CaptureCurvature=True
            sizing.CurvatureNormalAngle=Quantity(unicode(row.get("curvature_angle_deg",18))+" [deg]")
            sizing.LocalMinimumSize=Quantity(unicode(row.get("min_size_mm",row["size_mm"]/4.0))+" [mm]")
        if row["strategy"]=="mapped":
            for identifier in row["face_ids"]:
                face=faces[identifier]
                if unicode(face.SurfaceType)!="GeoSurfacePlane" or len(list(face.Edges))!=4:
                    raise Exception(u"映射方案当前只允许四边平面，不能静默改成其他方法")
            mapped=mesh.AddFaceMeshing();mapped.Name="AgentMappedFace_"+str(index+1);mapped.Location=selection
            mapped.MappedMesh=True;mapped.Method=FaceMeshingMethod.Quadrilaterals
        actual=dict(row,object_name=unicode(sizing.Name),actual_size_mm=quantity_value(sizing.ElementSize,"mm"),
            actual_behavior=unicode(sizing.Behavior))
        if row['strategy'] in ('transition','curvature'):actual['actual_growth_rate']=float(sizing.GrowthRate)
        if row['strategy']=='curvature':
            actual.update(actual_capture_curvature=bool(sizing.CaptureCurvature),actual_min_size_mm=quantity_value(sizing.LocalMinimumSize,'mm'),
                actual_curvature_angle_deg=quantity_value(sizing.CurvatureNormalAngle,'deg'))
        if row['strategy']=='mapped':actual['actual_mapped_method']=unicode(mapped.Method)
        applied.append(actual)
    return {"global_size_mm":quantity_value(mesh.ElementSize,'mm'),"controls":applied,"retained_controls":retained}


def collect_mesh_quality(model,analysis):
    import System
    import math
    mesh=model.Mesh;metrics={};native=[]
    # Warping and parallel deviation require a quadrilateral face; a pure-tet mesh has none.
    quad_shapes=("Quad4","Quad8","Hex8","Hex20","Wedge6","Wedge15","Pyramid5","Pyramid13")
    shape_counts={}
    for name in quad_shapes+("Tet4","Tet10"):
        try:shape_counts[name]=int(getattr(mesh,name))
        except Exception:pass
    has_quad_faces=any(shape_counts.get(name,0)>0 for name in quad_shapes)
    shape_known=bool(shape_counts)
    for key,definition in MESH_METRICS.items():
        # Definitions shown by the desktop come from mesh_policy; return only
        # native data here, avoiding IronPython 2's Latin-1 JSON string bug.
        row={"native_metric":definition[0],"unit":definition[3]}
        if key in ("warping_factor","parallel_deviation") and shape_known and not has_quad_faces:
            row.update(state="not_applicable",reason=u"纯四面体网格没有用于此指标的四边形面")
            metrics[key]=row;continue
        try:
            mesh.MeshMetric=System.Enum.Parse(mesh.MeshMetric.GetType(),definition[0])
            for field,attribute in (("minimum","Minimum"),("maximum","Maximum"),("average","Average"),("standard_deviation","StandardDeviation")):
                row[field]=mesh_quantity(getattr(mesh,attribute),definition[3] or None)
                if math.isnan(row[field]) or math.isinf(row[field]):raise Exception("Nonfinite mesh metric")
            row["state"]="available"
        except Exception as error:row.update(state="unavailable",reason=unicode(error))
        metrics[key]=row
    try:
        mesh.ComputeMeshQualityMetrics()
        for metric in mesh.GetVolumeMeshMetrics():
            native.append({"name":unicode(mesh.GetVolumeMeshQualityName(metric)),"metric":unicode(metric),
                "failed":int(mesh.GetVolumeMeshQualityCountFailed(metric)),
                "warning_failed":int(mesh.GetVolumeMeshQualityWarningCountFailed(metric)),
                "error_limit":unicode(mesh.GetVolumeMeshQualityErrorLimit(metric)),
                "warning_limit":unicode(mesh.GetVolumeMeshQualityWarningLimit(metric))})
    except Exception as error:native.append({"error":unicode(error)})
    return {"metrics":metrics,"native_checks":native,"shape_counts":shape_counts,
        "nodes":int(analysis.MeshData.NodeCount),"elements":int(analysis.MeshData.ElementCount),
        "scope":"whole_model","notice":u"质量统计针对全模型；局部面节点数不代表局部应力已收敛"}


def mesh_diagnostics_blocked(quality):
    import math
    for key,row in quality["metrics"].items():
        if row.get("state")!="available":continue
        if (key.startswith("jacobian_") or key=="element_quality") and row["minimum"]<=0:return True
    for row in quality["native_checks"]:
        if row.get('error'):return True
        if row.get("failed",0)>0:
            # Minimum edge length is a size statistic, not a shape-quality failure.
            if row.get("metric")!="MinEdgeLength":return True
    return False


def prepare_mesh(model,analysis,request):
    applied=apply_face_mesh_controls(model,request)
    model.Mesh.GenerateMesh()
    quality=collect_mesh_quality(model,analysis)
    budget=request.get("mesh_quality",{}).get("max_elements",200000)
    if request.get("max_elements") is not None:budget=min(budget,request["max_elements"])
    quality["max_elements"]=budget
    quality["budget_exceeded"]=quality["elements"]>budget
    quality["blocked"]=quality["elements"]<=0 or quality["budget_exceeded"] or mesh_diagnostics_blocked(quality)
    quality["face_regions"]=[]
    for identifier in sorted(set(i for row in request.get("mesh_controls",[]) for i in row["face_ids"])):
        try:
            region=analysis.MeshData.MeshRegionById(identifier)
            quality["face_regions"].append({"face_id":identifier,"nodes":len(list(region.NodeIds)),"region_elements":len(list(region.ElementIds))})
        except Exception as error:quality["face_regions"].append({"face_id":identifier,"error":unicode(error)})
    return applied,quality


def export_mesh_images(model,request):
    import System
    mesh=model.Mesh;artifacts=[];errors=[]
    metric_key=request.get("mesh_quality",{}).get("display_metric","skewness")
    native_name=MESH_METRICS[metric_key][0]
    if native_name=="OrthogonalAngle":native_name="OrthogonalQuality"
    for name,style in (("mesh.png","GeometrySetting"),("mesh_quality.png",native_name)):
        try:
            mesh.MeshMetric=System.Enum.Parse(mesh.MeshMetric.GetType(),"None")
            mesh.DisplayStyle=System.Enum.Parse(mesh.DisplayStyle.GetType(),style)
            mesh.Activate();ExtAPI.Graphics.Camera.SetFit()
            path=os.path.join(request["output"],name);ExtAPI.Graphics.ExportImage(path);artifacts.append(path)
        except Exception as error:errors.append(unicode(error))
    return artifacts,errors


def preview_mesh(model,request):
    project=ExtAPI.DataModel.Project
    project.SaveAs(os.path.join(request["output"],"case.mechdat"),False)
    analysis=unique(model.Analyses,request["analysis_name"])
    applied,quality=prepare_mesh(model,analysis,request)
    artifacts,errors=export_mesh_images(model,request)
    project.Save()
    return {"status":"MeshGenerated","mesh_nodes":quality["nodes"],"mesh_elements":quality["elements"],
        "mesh_plan":applied,"mesh_quality":quality,"artifacts":artifacts,"export_errors":errors,"solved":False}
