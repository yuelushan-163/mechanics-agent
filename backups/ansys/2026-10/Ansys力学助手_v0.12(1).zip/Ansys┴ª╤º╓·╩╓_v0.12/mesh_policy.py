"""Shared face-meshing plan and explicitly advisory quality reference."""
import copy
import math
import jsonschema

STRATEGIES={'uniform':'指定尺寸','coarse':'粗略预览','fine':'局部加密','transition':'平滑过渡','curvature':'曲率细化','mapped':'映射四边形面'}
PROFILES={'stress':'应力参考：平均纵横比 < 3','displacement':'位移参考：平均纵横比 < 7','report_only':'只报告，不套用参考阈值'}
METRICS={
 'skewness':('Skewness','倾斜度','越接近 0 越好',''),
 'element_quality':('ElementQuality','单元质量','越接近 1 越好',''),
 'aspect_ratio':('AspectRatio','纵横比','越接近 1 越好',''),
 'warping_factor':('WarpingFactor','扭曲系数','越接近 0 越好；限含四边形面的单元',''),
 'jacobian_mapdl':('JacobianRatio','Jacobian · MAPDL','正值，越接近 1 越好；最大/最小口径',''),
 'jacobian_corner':('JacobianRatioCornerNodes','Jacobian · 角点','最小/最大口径；≤0 有问题',''),
 'jacobian_gauss':('JacobianRatioGaussPoints','Jacobian · 高斯点','最小/最大口径；≤0 有问题',''),
 'parallel_deviation':('ParallelDeviation','平行偏差','越接近 0° 越好；限含四边形面的单元','deg'),
 'orthogonal_quality':('OrthogonalAngle','正交质量','越接近 1 越好',''),
 'maximum_corner_angle':('MaximumCornerAngle','最大内角','随单元形状解释，不能统一以 90° 为目标','deg')}
FACE_CONTROLS_SCHEMA={'type':'array','maxItems':100,'items':{'type':'object','additionalProperties':False,
 'required':['face_ids','strategy','size_mm'],'properties':{
 'face_ids':{'type':'array','minItems':1,'maxItems':1000,'uniqueItems':True,'items':{'type':'integer','minimum':1}},
 'strategy':{'enum':list(STRATEGIES)},'size_mm':{'type':'number','exclusiveMinimum':0},
 'growth_rate':{'type':'number','minimum':1.05,'maximum':2},
 'curvature_angle_deg':{'type':'number','minimum':1,'maximum':60},
 'min_size_mm':{'type':'number','exclusiveMinimum':0}}}}
QUALITY_SCHEMA={'type':'object','additionalProperties':False,'properties':{
 'profile':{'enum':list(PROFILES)},'max_elements':{'type':'integer','minimum':1,'maximum':2000000},
 'display_metric':{'enum':list(METRICS)}}}


def finite(value,name):
 if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):raise ValueError(name+' 必须是有限数值')
 return value


def validate_controls(value, faces=None):
 jsonschema.validate(value,FACE_CONTROLS_SCHEMA)
 seen=set();rows=copy.deepcopy(value)
 available={f['id']:f for f in faces} if faces is not None else None
 for row in rows:
  optional=set(row)-{'face_ids','strategy','size_mm'}
  supported={'growth_rate','curvature_angle_deg','min_size_mm'} if row['strategy']=='curvature' else ({'growth_rate'} if row['strategy']=='transition' else set())
  if optional-supported:raise ValueError('此方案不使用参数：'+', '.join(sorted(optional-supported)))
  for key in ('size_mm','growth_rate','curvature_angle_deg','min_size_mm'):
   if key in row:finite(row[key],key)
  if any(type(i) is not int for i in row['face_ids']):raise ValueError('面 ID 必须是整数')
  if seen.intersection(row['face_ids']):raise ValueError('同一面不能配置多个竞争网格方案，请合并或删除旧方案')
  seen.update(row['face_ids'])
  if row.get('min_size_mm',row['size_mm']/4)>row['size_mm']:raise ValueError('曲率最小尺寸不能大于局部尺寸')
  if available is not None:
   if any(i not in available for i in row['face_ids']):raise ValueError('网格作用面不属于当前模型')
   if row['strategy']=='mapped':
    for identifier in row['face_ids']:
     face=available[identifier]
     if 'Plane' not in face.get('surfacetype',face.get('type','')) or len(face.get('edge_ids',[]))!=4:
      raise ValueError('本版映射方案仅开放给四边平面；其他面请选尺寸或曲率细化')
 return rows


def validate_quality(value):
 jsonschema.validate(value,QUALITY_SCHEMA)
 if 'max_elements' in value and type(value['max_elements']) is not int:raise ValueError('单元预算必须是整数')
 return {'profile':'stress','max_elements':200000,'display_metric':'skewness',**value}


def scaled_controls(controls,factor):
 result=validate_controls(controls)
 for row in result:
  row['size_mm']*=factor
  if 'min_size_mm' in row:row['min_size_mm']*=factor
 return result


def quality_reference(metrics,options):
 """User-provided reference warnings; never claim engineering acceptance."""
 settings=validate_quality(options);checks=[]
 def add(status,metric,reason,**data):checks.append(dict(status=status,metric=metric,reason=reason,**data))
 for key in METRICS:
  row=metrics.get(key,{})
  if row.get('state')=='not_applicable':
   add('not_applicable',key,row.get('reason','当前单元形状不适用'));continue
  if row.get('state')!='available':
   add('warn',key,'无法读取此指标，需在 Mechanical 中人工核对');continue
  values=[row.get(k) for k in ('minimum','maximum','average','standard_deviation')]
  if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for v in values):
   add('block',key,'质量统计不是有效有限数值');continue
  if key.startswith('jacobian_') and row['minimum']<=0:
   add('block',key,'Jacobian 比值非正，需修复网格后再求解',actual=row['minimum'])
  if key=='element_quality' and row['minimum']<=0:add('block',key,'存在零或负单元质量',actual=row['minimum'])
 if settings['profile']!='report_only':
  refs=[('skewness','maximum',.95,'lt'),('element_quality','average',.7,'gt'),
   ('aspect_ratio','average',3 if settings['profile']=='stress' else 7,'lt'),
   ('parallel_deviation','maximum',70,'lt'),('maximum_corner_angle','maximum',179.9,'lt')]
  for key,stat,limit,operator in refs:
   row=metrics.get(key,{})
   if row.get('state')!='available':continue
   actual=row.get(stat)
   if not isinstance(actual,(int,float)) or not math.isfinite(actual):continue
   passed=actual<limit if operator=='lt' else actual>limit
   add('pass' if passed else 'warn',key,'用户提供的参考预警；非 Ansys 统一验收标准',statistic=stat,actual=actual,
       reference_limit=limit,comparison=operator,source='本次用户提供的网格评价参考')
 return {'status':'blocked' if any(c['status']=='block' for c in checks) else ('human_review_required' if any(c['status']=='warn' for c in checks) else 'reference_checks_passed'),
  'checks':checks,'notice':'指标通过不代表应力/位移已收敛或工程已验收'}
